def dfs(graph, start,arr):
    if start in arr:
        return
    arr+=[start]
    for i in graph[start]:
        for j in i:
            dfs(graph,j,arr)
    

graph = {'0': ['1', '2'],
         '1': ['0', '3', '4'],
         '2': ['0'],
         '3': ['1'],
         '4': ['2', '3']
         }
arr=[]
dfs(graph, '0',arr)
print(arr)
