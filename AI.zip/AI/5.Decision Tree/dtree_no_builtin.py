#Decision Tree without built in function for and operation

import numpy as np
class DecisionNode:
    def __init__(self, feature=None, threshold=None, left=None, right=None, value=None):
        self.feature = feature  # Index of the feature to split on
        self.threshold = threshold  # Threshold for the feature
        self.left = left  # Left subtree
        self.right = right  # Right subtree
        self.value = value  # Value to return if it's a leaf node (0 or 1)

def build_decision_tree(data, target):
    if len(set(target)) == 1:  # If all target values are the same, return a leaf node
        return DecisionNode(value=target[0])

    if len(data[0]) == 1:  # If there's only one feature left, return a leaf node with the majority target value
        majority_value = max(set(target), key=target.count)
        return DecisionNode(value=majority_value)

    # Find the best feature and threshold to split on
    best_feature, best_threshold = None, None
    best_gini = 1  # Initialize Gini impurity with the maximum value

    for feature in range(len(data[0])):
        for threshold in set(data[:, feature]):
            left_indices = data[:, feature] < threshold
            right_indices = ~left_indices

            left_target = target[left_indices]
            right_target = target[right_indices]

            if len(left_target) == 0 or len(right_target) == 0:
                continue

            gini_left = 1 - sum((left_target == c).mean() ** 2 for c in set(left_target))
            gini_right = 1 - sum((right_target == c).mean() ** 2 for c in set(right_target))

            gini = (len(left_target) / len(target)) * gini_left + (len(right_target) / len(target)) * gini_right

            if gini < best_gini:
                best_gini = gini
                best_feature = feature
                best_threshold = threshold

    if best_gini == 1:  # If no good split is found, return a leaf node with the majority target value
        majority_value = max(set(target), key=target.count)
        return DecisionNode(value=majority_value)

    # Split the dataset into left and right subtrees
    left_data = data[data[:, best_feature] < best_threshold]
    left_target = target[data[:, best_feature] < best_threshold]
    right_data = data[data[:, best_feature] >= best_threshold]
    right_target = target[data[:, best_feature] >= best_threshold]

    left_subtree = build_decision_tree(left_data, left_target)
    right_subtree = build_decision_tree(right_data, right_target)

    return DecisionNode(feature=best_feature, threshold=best_threshold, left=left_subtree, right=right_subtree)

def predict_tree(node, data_point):
    if node.value is not None:
        return node.value
    if data_point[node.feature] < node.threshold:
        return predict_tree(node.left, data_point)
    else:
        return predict_tree(node.right, data_point)

# Sample AND gate training data
data = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
target = np.array([0, 0, 0, 1])

# Build the decision tree
decision_tree = build_decision_tree(data, target)

# Test the decision tree
test_data = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
predictions = [predict_tree(decision_tree, data_point) for data_point in test_data]

for i, prediction in enumerate(predictions):
    print(f"Input: {test_data[i]}, Prediction: {prediction}")
