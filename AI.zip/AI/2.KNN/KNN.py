import csv

data=[]

with open ('C:/Users/T Nikhil/Desktop/AI/KNN/archive/IRIS.csv','r')as f:
    a=csv.reader(f)
    for i in a:
        data.append(i)

inp=[1,2,0,3]

d={}
length=0


for i in data:
        
    dis = ((float(i[0]) - inp[0]) ** 2 + (float(i[1]) - inp[1]) ** 2 + (float(i[2]) - inp[2]) ** 2 + (float(i[3]) - inp[3]) ** 2) ** 0.5
    data[length].append(dis)
    length+=1
    
sortedarray=sorted(data,key=lambda x:x[-1]) #sort wrt distance

k=5
setosa=0
versicolor=0
virginica=0

i=0
length=len(sortedarray[0])
while k>0:
    if sortedarray[i][length-2]=="Iris-setosa":
       setosa+=1
    elif sortedarray[i][length-2]=="Iris-versicolor":
        versicolor+=1
    else:
        virginica+=1
    k-=1

if setosa>versicolor and setosa>virginica:
    print("Setosa")
elif versicolor>setosa and versicolor>virginica:
    print("Versicolor")
elif virginica>setosa and virginica>versicolor:
    print("Virginica")
else:
    print("Nothing")
    
    
    






    
