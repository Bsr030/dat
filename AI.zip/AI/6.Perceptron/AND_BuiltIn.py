from sklearn.linear_model import Perceptron
import numpy as np

# AND gate training data
X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
y = np.array([0, 0, 0, 1])

# Create a Perceptron classifier
clf = Perceptron(max_iter=1000, tol=1e-3)

# Train the Perceptron
clf.fit(X, y)

# Test the Perceptron
test_data = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
predictions = clf.predict(test_data)

for i in range(len(test_data)):
    print(f"Input: {test_data[i]}, Prediction: {predictions[i]}")
