import random

training_data = [([0, 0], 0), ([0, 1], 0), ([1, 0], 0), ([1, 1], 1)]
weights, bias, learning_rate, activate = [random.uniform(-1, 1), random.uniform(-1, 1)], random.uniform(-1, 1), 0.1, lambda x: 1 if x > 0 else 0

for _ in range(1000):
    total_error = 0
    for input_data, target in training_data:
        weighted_sum = sum(w * x for w, x in zip(weights, input_data)) + bias
        prediction = activate(weighted_sum)
        error = target - prediction
        weights = [w + learning_rate * error * x for w, x in zip(weights, input_data)]
        bias += learning_rate * error
        total_error += error
    if total_error == 0:
        break

print("Trained Weights:", weights)
print("Trained Bias:", bias)
print("Testing...")

for input_data, target in training_data:
    weighted_sum = sum(w * x for w, x in zip(weights, input_data)) + bias
    prediction = activate(weighted_sum)
    print(f"Input: {input_data}, Target: {target}, Prediction: {prediction}")
