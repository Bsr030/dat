import csv

inputdata=[]

with open('C:/Users/T Nikhil/Desktop/AI/FINDS/archive/ws.csv','r') as f:
    a=csv.reader(f)
    for i in a:
        inputdata.append(i)
        print(i)

#print(inputdata)
length=len(inputdata[0])-1
hypo=['0']*length

print(length)

print(hypo)

for i in range(len(inputdata)):
    if inputdata[i][length]=='Yes':
        for j in range(length):
            if hypo[j]=='0':
                hypo[j]=inputdata[i][j]
            elif hypo[j]!=inputdata[i][j]:
                hypo[j]='?'
        print(hypo)
print()
print("Output is")
print(hypo)
          
