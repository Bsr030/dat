import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

dataset=pd.read_csv("C:/Users/T Nikhil/Desktop/AI/Regression/Linear Regression/Salary_Data.csv")

x=dataset.iloc[: , :-1].values
y=dataset.iloc[: , -1].values

x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.1,random_state=0)



from sklearn.model_selection import *

reg=LinearRegression()
reg.fit(x_train,y_train)

y_pred=reg.predict(x_test)


#Training set graph
plt.scatter(x_train,y_train)
plt.plot(x_train,reg.predict(x_train))
plt.title('Salary vs Experience')
plt.xlabel('Experience')
plt.ylabel('Salary')
plt.show()

#Test set graph
plt.scatter(x_test,y_test)
plt.plot(x_test,reg.predict(x_test))
plt.title('Salary vs Experience')
plt.xlabel('Experience')
plt.ylabel('Salary')
plt.show()
