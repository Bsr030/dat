from queue import Queue

class State:
    def __init__(self, missionaries_left, cannibals_left, boat, missionaries_right, cannibals_right, parent=None):
        self.missionaries_left = missionaries_left
        self.cannibals_left = cannibals_left
        self.boat = boat
        self.missionaries_right = missionaries_right
        self.cannibals_right = cannibals_right
        self.parent = parent

    def __eq__(self, other):
        return (
            self.missionaries_left == other.missionaries_left and
            self.cannibals_left == other.cannibals_left and
            self.boat == other.boat and
            self.missionaries_right == other.missionaries_right and
            self.cannibals_right == other.cannibals_right
        )

    def __hash__(self):
        return hash((self.missionaries_left, self.cannibals_left, self.boat,
                     self.missionaries_right, self.cannibals_right))

    def is_valid(self):
        if (
            0 <= self.missionaries_left <= 3 and
            0 <= self.cannibals_left <= 3 and
            0 <= self.missionaries_right <= 3 and
            0 <= self.cannibals_right <= 3 and
            (self.missionaries_left == 0 or self.missionaries_left >= self.cannibals_left) and
            (self.missionaries_right == 0 or self.missionaries_right >= self.cannibals_right)
        ):
            return True
        return False

    def is_goal(self):
        return self.missionaries_left == 0 and self.cannibals_left == 0

def get_neighbors(state):
    neighbors = []

    for m, c in [(1, 0), (2, 0), (0, 1), (0, 2), (1, 1)]:
        if state.boat == 'left':
            neighbor = State(state.missionaries_left - m, state.cannibals_left - c, 'right',
                             state.missionaries_right + m, state.cannibals_right + c, state)
        else:
            neighbor = State(state.missionaries_left + m, state.cannibals_left + c, 'left',
                             state.missionaries_right - m, state.cannibals_right - c, state)

        if neighbor.is_valid():
            neighbors.append(neighbor)

    return neighbors

def breadth_first_search(initial_state):
    visited = set()
    queue = Queue()
    queue.put(initial_state)

    while not queue.empty():
        current_state = queue.get()

        if current_state.is_goal():
            return current_state

        visited.add(current_state)

        for neighbor in get_neighbors(current_state):
            if neighbor not in visited:
                queue.put(neighbor)

    return None

def print_solution(solution):
    if solution:
        path = []
        while solution:
            path.insert(0, solution)
            solution = solution.parent

        for t in path:
            print(f"{t.missionaries_left}M-{t.cannibals_left}C {t.boat} {t.missionaries_right}M-{t.cannibals_right}C")
    else:
        print("No solution found.")

# Example usage:
initial_state = State(3, 3, 'left', 0, 0)
solution_state = breadth_first_search(initial_state)

print_solution(solution_state)
