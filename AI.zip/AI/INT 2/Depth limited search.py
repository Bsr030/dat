class Node:
    def __init__(self, data):
        self.data = data
        self.children = []

def depth_limited_search(node, goal, depth_limit):
    if node.data == goal:
        return True
    elif depth_limit == 0:
        return False
    else:
        for child in node.children:
            if depth_limited_search(child, goal, depth_limit - 1):
                return True
        return False

# Example usage:
# Construct a tree for testing
#         1
#       / | \
#      2  3  4
#     / \    |
#    5   6   7
root = Node(1)
root.children = [Node(2), Node(3), Node(4)]
root.children[0].children = [Node(5), Node(6)]
root.children[2].children = [Node(7)]

# Set the depth limit to 2
depth_limit = 2

# Test the depth-limited search
goal_node = 7
result = depth_limited_search(root, goal_node, depth_limit)

if result:
    print(f"Goal {goal_node} found within the depth limit.")
else:
    print(f"Goal {goal_node} not found within the depth limit.")
