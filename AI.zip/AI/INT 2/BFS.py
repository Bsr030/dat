from collections import deque

def bfs(graph,start,arr):
    q = deque()
    q.append(start)
    visited=[0 for i in range(len(graph))]
    while len(q)>0:
        a=q.popleft()
        if visited[int(a)]==0:
            visited[int(a)]=1
            arr.append(a)
            for i in graph[a]:
                for j in i:
                    if visited[int(j)]==0:
                        q.append(j)

graph = {'0': ['1', '2'],
         '1': ['0', '3', '4'],
         '2': ['0'],
         '3': ['1'],
         '4': ['2', '3']
         }
arr=[]
bfs(graph, '0',arr)
print(arr)
