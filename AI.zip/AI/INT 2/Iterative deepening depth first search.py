class Node:
    def __init__(self, data):
        self.data = data
        self.children = []

def depth_limited_search(node, goal, depth_limit):
    stack = [(node, 0)]

    while stack:
        current_node, current_depth = stack.pop()

        if current_node.data == goal:
            return True

        if current_depth < depth_limit:
            # Add child nodes to the stack with increased depth
            stack.extend((child, current_depth + 1) for child in reversed(current_node.children))

    return False

def iterative_deepening_search(root, goal):
    depth_limit = 0
    while True:
        result = depth_limited_search(root, goal, depth_limit)
        if result:
            return True
        depth_limit += 1

# Example usage:
# Construct a tree for testing
#         1
#       / | \
#      2  3  4
#     / \    |
#    5   6   7
root = Node(1)
root.children = [Node(2), Node(3), Node(4)]
root.children[0].children = [Node(5), Node(6)]
root.children[2].children = [Node(7)]

# Test the iterative deepening search
goal_node = 7
result = iterative_deepening_search(root, goal_node)

if result:
    print(f"Goal {goal_node} found.")
else:
    print(f"Goal {goal_node} not found.")
