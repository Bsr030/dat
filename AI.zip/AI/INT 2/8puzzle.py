import heapq

class PuzzleState:
    def __init__(self, board, parent=None, g=0, h=0):
        self.board = board
        self.parent = parent
        self.g = g  # Cost from start node to current node
        self.h = h  # Heuristic cost from current node to goal node

    def __lt__(self, other):
        return (self.g + self.h) < (other.g + other.h)

    def __eq__(self, other):
        return self.board == other.board

def print_board(board):
    for row in board:
        print(" ".join(str(cell) if cell != 0 else " " for cell in row))
    print()

def find_blank(board):
    for i, row in enumerate(board):
        for j, cell in enumerate(row):
            if cell == 0:
                return i, j

def heuristic(board, goal_board):
    h = 0
    for i in range(3):
        for j in range(3):
            if board[i][j] != goal_board[i][j]:
                h += 1
    return h

def get_neighbors(state, goal_board):
    neighbors = []
    i, j = find_blank(state.board)

    moves = [(0, 1), (1, 0), (0, -1), (-1, 0)]
    for di, dj in moves:
        ni, nj = i + di, j + dj
        if 0 <= ni < 3 and 0 <= nj < 3:
            new_board = [row.copy() for row in state.board]
            new_board[i][j], new_board[ni][nj] = new_board[ni][nj], new_board[i][j]
            neighbors.append(PuzzleState(new_board, state, state.g + 1, heuristic(new_board, goal_board)))

    return neighbors

def a_star_search(initial_state, goal_board):
    open_set = [initial_state]
    closed_set = set()

    while open_set:
        current_state = heapq.heappop(open_set)

        if current_state.board == goal_board:
            path = []
            while current_state:
                path.insert(0, current_state.board)
                current_state = current_state.parent
            return path

        closed_set.add(tuple(map(tuple, current_state.board)))

        for neighbor in get_neighbors(current_state, goal_board):
            if tuple(map(tuple, neighbor.board)) not in closed_set:
                heapq.heappush(open_set, neighbor)

    return None

# Example usage:
initial_board = [
    [1, 2, 3],
    [4, 0, 5],
    [6, 7, 8]
]

goal_board = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 0]
]

initial_state = PuzzleState(initial_board)
path = a_star_search(initial_state, goal_board)

if path:
    print("A* Path found:")
    for board in path:
        print_board(board)
else:
    print("No path found.")
